package testtax;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TaxProfileandRates {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException, AWTException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/src/main/resources/drivers/chromedriver.exe");
driver=new ChromeDriver();
driver.get("https://indigo-testing.shireburn.com/");
driver.manage().window().maximize();
validInvalidLogin();
Insert();
InsertEdge();
Delete();
Edit();
Toolbar();
AddRates();
EditandDeleteRates();
AddRatesEdge();
ToolbarRates();
driver.close();
	
	}
	
	public static void validInvalidLogin() throws InterruptedException {
		
		//valid username and Password
		WebElement pwd=driver.findElement(By.id("txtPassword"));
		WebElement un=driver.findElement(By.id("txtUsername"));
		un.sendKeys("IntQA07");
	
		pwd.sendKeys("Ne69332480.");
		driver.findElement(By.id("submit")).click();
		Thread.sleep(5000);
		System.out.println(driver.getTitle());
		//Invalid username and valid Password
		
		
		//cannot execute since entering invalid credentials ask for confirmation
		/*driver.get("https://indigo-testing.shireburn.com/");
				un.sendKeys("test");
		
				pwd.sendKeys("Ne69332480.");
		driver.findElement(By.id("submit")).click();
		
		System.out.println(driver.findElement(By.className("loginMessage")).getText());
		
		//Invalid Password and valid Username
		un.sendKeys(Keys.CONTROL,"A");
		un.sendKeys(Keys.DELETE);
				driver.findElement(By.id("txtUsername")).sendKeys("IntQA07");
				pwd.sendKeys(Keys.CONTROL,"A");
				pwd.sendKeys(Keys.DELETE);
				driver.findElement(By.id("txtPassword")).sendKeys("test");
				driver.findElement(By.id("submit")).click();
				System.out.println(driver.findElement(By.className("loginMessage")).getText());
				
				//Invalid Password and Invalid Username
				un.sendKeys(Keys.CONTROL,"A");
				un.sendKeys(Keys.DELETE);
				driver.findElement(By.id("txtUsername")).sendKeys("test");
				pwd.sendKeys(Keys.CONTROL,"A");
				pwd.sendKeys(Keys.DELETE);
				driver.findElement(By.id("txtPassword")).sendKeys("test");
				driver.findElement(By.id("submit")).click();
				System.out.println(driver.findElement(By.className("loginMessage")).getText());	
		*/				
		
	}
	public static void robotenter(String input) throws AWTException {
		Robot robot = new Robot();
	Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	//Set the String to Enter

	  StringSelection stringSelection = new StringSelection(input);
	//Copy the String to Clipboard	

	  clipboard.setContents(stringSelection, null);
	//Use Robot class instance to simulate CTRL+C and CTRL+V key events :

	  robot.keyPress(KeyEvent.VK_CONTROL);
	  robot.keyPress(KeyEvent.VK_V);
	  robot.keyRelease(KeyEvent.VK_V);
	  robot.keyRelease(KeyEvent.VK_CONTROL);
	//Simulate Enter key event
	  robot.keyPress(KeyEvent.VK_TAB);
	robot.keyRelease(KeyEvent.VK_TAB);
	
	 
	}
	public static void Insert() throws InterruptedException, AWTException
	
	{
	
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(15000);
		driver.findElement(By.id("insertButton")).click();
		/*
		 * WebElement
		 * add=driver.findElement(By.className("currentRow")).findElement(By.tagName(
		 * "input")); add.click(); add.sendKeys("tebu74 K@"); add.clear();
		 * add.sendKeys("G2-Married");
		 * 
		 * 
		 * WebElement desc=driver.findElements(By.id("jqx-input-metro")).get(2);
		 * desc.sendKeys("dgy37%"); desc.clear(); desc .sendKeys("Tax Profile for G2");
		 * 
		 * WebElement FSS= driver.findElement(By.id(
		 * "dropdownlistContentdropdownlisteditorjqxWidgeta8c389b5bbeaFssStatusType"));
		 * FSS.click();
		 * 
		 * driver.findElement(By.className("jqx-listitem-element")).click();
		 * 
		 * driver.findElement(By.id("cancelButton")).click();
		 * 
		 * Thread.sleep(10000); driver.findElement(By.id("insertButton")).click();
		 * add.sendKeys("G2-Married");
		 * 
		 * 
		 * desc .sendKeys("Tax Profile for G2");
		 */
		
		robotenter("dey45u$");
		
		robotenter("dey45u$");
		//driver.findElement(By.cssSelector("div[data-uid='TaxProfile-Description']")).sendKeys("dey45u$");
		driver.findElement(By.id("cancelButton")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("insertButton")).click();
		robotenter("G23-Married");
		robotenter("Tax Profile for G23");
		driver.findElement(By.id("saveButton")).click();
		
		Thread.sleep(15000);
		
		
		
		
		
	}
	
	
	
public static void InsertEdge() throws InterruptedException, AWTException
	
	{
	
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(15000);
	int before=	driver.findElements(By.cssSelector("div[role='row']")).size();
		driver.findElement(By.id("insertButton")).click();
		Thread.sleep(6000);
robotenter("dey45u$");
	
driver.close();
driver=new ChromeDriver();
driver.get("https://indigo-testing.shireburn.com/");
Thread.sleep(5000);
driver.manage().window().maximize();
validInvalidLogin();

driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");

System.out.println("Same rows"+ before);

		
	}
	
	public static void Delete() throws InterruptedException, AWTException
	{
		
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
		driver.findElements(By.className("jqx-checkbox-default")).get(3).click();
		driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
		
	driver.findElement(By.id("deleteActionButton")).click();
	Thread.sleep(5000);
	Robot robot= new Robot();
	robot.keyPress(KeyEvent.VK_D);
	robot.keyRelease(KeyEvent.VK_D);
	Thread.sleep(8000);
	}

	public static void Edit() throws InterruptedException, AWTException {
		
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
		
		driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
		driver.findElement(By.id("editButton")).click();
		Thread.sleep(15000);
		robotenter("Tax Profile for G23");
		
driver.findElement(By.id("saveButton")).click();
		
		Thread.sleep(6000);
		
		
		
	}
	
	public static void Toolbar() throws InterruptedException, AWTException
	{
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
		
		driver.findElement(By.id("saveStateButton")).click();
		Thread.sleep(6000);
		
		driver.findElement(By.id("copyButton")).click();
		driver.findElement(By.id("pasteButton")).click();
		
		robotenter("Tax Profile for G23");
driver.findElement(By.id("saveButton")).click();
		
		Thread.sleep(6000);
		
		driver.findElement(By.id("navigateFirstButton")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("navigateLastButton")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("navigatePreviousPageButton")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("navigateNextPageButton")).click();
		
		Thread.sleep(6000);
		driver.findElement(By.id("navigateNextRecordButton")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("navigatePreviousRecordButton")).click();
		
		
		
	}
	
	public static void AddRates() throws InterruptedException, AWTException {
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
		driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
		driver.findElement(By.id("taxratebutton")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("insertButton")).click();
		Thread.sleep(6000);
robotenter("pt23456");
driver.findElement(By.id("saveButton")).click();
Thread.sleep(6000);
		
	}
	
	
	public static void EditandDeleteRates() throws InterruptedException, AWTException {
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
		driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
		driver.findElement(By.id("taxratebutton")).click();
		Thread.sleep(5000);
		driver.findElements(By.className("jqx-checkbox-default")).get(3).click();
		Thread.sleep(5000);
		driver.findElement(By.id("editButton")).click();
		Thread.sleep(6000);
robotenter("pt2345667");
driver.findElement(By.id("saveButton")).click();
Thread.sleep(8000);

driver.findElements(By.className("jqx-checkbox-default")).get(3).click();

driver.findElement(By.id("deleteActionButton")).click();

Thread.sleep(4000);

Robot robot= new Robot();

robot.keyPress(KeyEvent.VK_D);
robot.keyRelease(KeyEvent.VK_D);
Thread.sleep(8000);
		
	}
	
	
	public static void AddRatesEdge() throws InterruptedException, AWTException {
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
		driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
		driver.findElement(By.id("taxratebutton")).click();
		Thread.sleep(5000);
		int before =driver.findElements(By.cssSelector("div[role='row']")).size();
		driver.findElement(By.id("insertButton")).click();
		Thread.sleep(6000);
robotenter("pt23456");
driver.close();
driver=new ChromeDriver();
driver.get("https://indigo-testing.shireburn.com/");
Thread.sleep(5000);
driver.manage().window().maximize();
validInvalidLogin();

driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
Thread.sleep(10000);
driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
driver.findElement(By.id("taxratebutton")).click();
Thread.sleep(5000);
System.out.println("Same rows"+ before);
		
	}
	
	public static void ToolbarRates() throws InterruptedException, AWTException
	{
		driver.get("https://indigo-testing.shireburn.com/#/List/00103/QA01/HR/Payroll/TaxProfiles");
		Thread.sleep(10000);
	
		driver.findElements(By.className("jqx-checkbox-default")).get(2).click();
		driver.findElement(By.id("taxratebutton")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("saveStateButton")).click();
		Thread.sleep(6000);
		
		driver.findElement(By.id("copyButton")).click();
		driver.findElement(By.id("pasteButton")).click();
		
		robotenter("Tax23R3");
driver.findElement(By.id("saveButton")).click();
		
		Thread.sleep(6000);
		
		driver.findElement(By.id("navigateFirstButton")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("navigateLastButton")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("navigatePreviousPageButton")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("navigateNextPageButton")).click();
		
		Thread.sleep(6000);
		driver.findElement(By.id("navigateNextRecordButton")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("navigatePreviousRecordButton")).click();
		
		Thread.sleep(3000);
		
	}
	
}
